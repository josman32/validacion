<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/app.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item active">
              <a class="nav-link" href="/">INICIO</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="datos">REGISTRARSE</a>
            </li>
          </ul>
        </div>
      </nav>
      <H1>Registrar estudiante</H1>
    <div class="card-body">
        <form action="" method="POST">
            <div class="form-group">
              <label for="lcodigo">Codigo</label>
              <input maxlength="10" minlength="10" type="text" class="form-control" id="lcodigo" placeholder="Ingresar codigo" required>
            </div>
            <div class="form-group">
              <label for="lnombre">Nombre</label>
              <input maxlength="30" minlength="10" type="text" class="form-control" id="lnombre" placeholder="Ingresar Nombre" required="" pattern="[a-zA-Z]+">
            </div>
            <div class="form-group">
                <label for="ldireccion">Direccion</label>
                <input maxlength="100" minlength="10" type="text" class="form-control" id="ldireccion" placeholder="Ingresar Direccion" required>
              </div>
              <div class="form-group">
                <label for="ltelefono">Telefono</label>
                <input maxlength="20" minlength="8" type="tel" class="form-control" id="ltelefono" placeholder="Ingresar Numero" required="" pattern="[0-9]+">
              </div>
              <div class="form-group">
                <label for="lemail">Email</label>
                <input maxlength="20" minlength="10" type="email" class="form-control" id="lemail" placeholder="Ingresar Email" required>
              </div>
              <br>
            <button type="submit" class="btn btn-primary">Enter</button>
             
          </form>
    </div>
</body>
<style>
    body{
        background-color: rgb(136, 173, 241);
    }
</style>
</html>